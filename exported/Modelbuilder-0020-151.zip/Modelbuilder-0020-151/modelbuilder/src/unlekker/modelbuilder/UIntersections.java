package unlekker.modelbuilder;

public class UIntersections {

	public static UVec3 linePlaneIntersection(UVec3 pt1,UVec3 pt2, UVec3 planePt, UVec3 planeN) {
		UVec3 res=new UVec3();
		
	  //http://paulbourke.net/geometry/planeline/

		return res;
	}
}
