package unlekker.util;

import java.util.ArrayList;
import processing.core.*;

public class UText {
	public PFont font;
	public PApplet p;
	public float margin[]={0,0,0,0};
	public float padding[]={0,0,0,0};
	public int color,backgroundColor;
}
