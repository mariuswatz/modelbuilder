import processing.core.*; 
import processing.xml.*; 

import unlekker.util.*; 
import unlekker.modelbuilder.*; 
import unlekker.modelbuilder.filter.*; 
import ec.util.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class UTimerDemo extends PApplet {

/**
 * UTimerDemo.pde - Marius Watz, 2012
 * http://workshop.evolutionzone.com
 *
 * Demonstrates the use of global and local time (T) to control
 * drawing behavior using the UTimer class from Modelbuilder.
 *
 */








Particle part[];
float globalT;
UColorTool colors;

public void setup() {
  size(600, 600, P3D);

  initColors();
  initScene();  
}

public void draw() {
  background(0);
  lights();
  
  // calculate global T
  globalT=(float)(frameCount%500)/500f;

  // rotate camera according to global T
  translate(width/2, height/2);
  rotateX(radians(-30+globalT*60));
  rotateY(radians(30-globalT*60));
  
  // draw 3D axis indicator to show global rotation
  fill(255);
  noStroke();
  pushMatrix();
  box(100,2,2);
  rotateY(HALF_PI);
  box(100,2,2);
  rotateZ(HALF_PI);
  box(100,2,2);
  popMatrix();
  
  // draw objects
  stroke(0);
  for (int i=0; i<part.length; i++) part[i].draw();
  
  // re-initialize scene if globalT > 0.999f.
  // note: never check for globalT==1, floats aren't reliable due to rounding
  if(globalT>0.999f) initScene();
}

public void initScene() {
  // initialize scene
  part=new Particle[(int)random(50, 100)];
  for (int i=0; i<part.length; i++) part[i]=new Particle();
}

public void initColors() {
  colors=new UColorTool();
  colors.addGradient(3, 10, "02D4E5", "1D385A");
  colors.addGradient(3, 10, "FFFF00", "FFFFFF");
  colors.addGradient(3, 10, "FFB700", "FF680A");
  colors.generateColors();
}


class Particle {
  float x, y, rad;
  int col;
  UTimer time;

  Particle() {
    x=random(-0.5f, 0.5f)*(float)width;
    y=random(-0.5f, 0.5f)*(float)height;
    rad=random(10, 40);
    if (random(100)>90) rad=random(80, 120);

    // tStart = [0 .. 0.5]
    float tStart=random(50)/100;
    float tDur=random(0.2f, 1-tStart);
    time=new UTimer(tStart, tDur);

    col=colors.getRandomColor();
  }

  public void draw() {
    // update UTimer with global time == [0..1]
    time.update(globalT);

    if (time.t<0 || time.t>1) return; // not born or dead -> don't draw

    // calc radius and color based on time.t (local time)
    float theRad=sin(PI*time.t)*rad;
    
    // set transparent fill based on sin(T) so that object fades in and out
    fill(col, sin(PI*time.t)*200);

    pushMatrix();
    translate(x, y, 0);
    rotateY(PI*time.t);
    box(theRad, theRad, theRad*5);
    popMatrix();
  }
}

  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#F0F0F0", "UTimerDemo" });
  }
}
