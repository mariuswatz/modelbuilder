ModelBuilder v0003, April 6, 2011

This is the first public release of ModelBuilder, a Processing library 
to facilitate building 3D meshes for digital fabrication. It succeeds 
the old unlekkerLib library, which should now be considered obsolete.

Please visit the following link for more information:
http://workshop.evolutionzone.com/2011/04/06/code-modelbuilder-library-public-release/

Copyright Marius Watz, 2011

http://mariuswatz.com 
http://unlekker.net
http://flickr.com/photos/watz
http://twitter.com/mariuswatz

----------------------------------------------------------------------

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

http://creativecommons.org/licenses/LGPL/2.1/

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301, USA